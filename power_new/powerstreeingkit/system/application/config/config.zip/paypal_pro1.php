<?php  
if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$config['Sandbox'] = TRUE;
$config['APIVersion'] = '66.0';
$config['APIUsername'] = 'sandbo_1215254764_biz_api1.angelleye.com';
$config['APIPassword'] = '1215254774';
$config['APISignature'] = 'AFcWxV21C7fd0v3bYYYRCpSSRl31A8yUF6SKTYho-1n.lV4AafhTVyaQ';
$config['BetaSandbox'] = TRUE;
/* End of file paypal_pro.php */
/* Location: ./system/application/config/paypal_pro.php */

?>