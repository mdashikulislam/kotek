<h1 class="pageTitle"><?php echo $title;?></h1>
<div class="dashboardWrapper">
    <table cellpadding="3" cellspacing="0" border="0" class="dashboardTableWrapper">
                    <tr>
                        <th width="140"> Name </th>
                        <th width="340"> Description </th>
                        <th width="140"> Name </th>
                        <th width="340"> Description </th>
                    </tr>
                    
                    <tr class="odd">
                        <td> <?php echo anchor("admin/pages/","Manage Pages");?> </td>
                        <td> Create, edit, delete and manage Pages fonts on your online store. </td>
                        <td> <?php //echo anchor("admin/videos/","Manage Videos");?> </td>
                        <td> <!-- Create, edit, delete and manage Videos fonts on your online store. --> </td>
                    </tr>
                    
                    <tr class="even">
                        <td> <?php echo anchor("admin/maker/","Manage Makers");?> </td>
                        <td> Create, edit, delete and manage Makers fonts on your online store. </td>
                        <td> <?php echo anchor("admin/faq/","Manage FAQ");?> </td>
                        <td> Create, edit, delete and manage FAQs on your online store. </td>
                    </tr>
                    
                    <tr class="odd">
                        <td> <?php echo anchor("admin/categories/","Manage Categories");?> </td>
                        <td> Create, edit, delete and manage Categories fonts on your online store. </td>
                        <td> <?php echo anchor("admin/news/","Manage News");?> </td>
                        <td> Create, edit, delete and manage News on your online store. </td>
                    </tr>
                    
                    <tr class="even">
                        <td> <?php echo anchor("admin/products/","Manage Products");?> </td>
                        <td> Create, edit, delete and manage products on your online store. </td>
                        <td> <?php echo anchor("admin/testimonial/","Manage Testimonial");?> </td>
                        <td> Create, edit, delete and manage Testimonials on your online store. </td>
                    </tr>
                    
                    <tr class="odd">
                        <td> <?php echo anchor("admin/distributors/","Manage Distributors");?> </td>
                        <td> Create, edit, delete and manage Distributors on your online store. </td>
                        <td> <?php echo anchor("admin/banner/","Manage Banners");?> </td>
                        <td> Create, edit, delete and manage Banners on your online store. </td>                    
                    </tr>
                    
                    <tr class="even">
                        <td> <?php echo anchor("admin/subscribers/","Manage Subscribers");?> </td>
                        <td> Manage subscribers and send out emails. </td>
                        <td> <?php echo anchor("admin/admins/","Manage Admin Users");?> </td>
                        <td> Create, edit, delete and manage Admin Users on your online store. </td>                    
                    </tr>
                    
                    <tr class="odd">
                        <td> <?php echo anchor("admin/orders/customers/","Manage Customers");?> </td>
                        <td> Manage Customers and send out emails. </td>
                        <td> <?php echo anchor("admin/dashboard/logout/","Logout");?> </td>
                        <td>Exit this dashboard when you're done. </td>
                    </tr>
                </table>
</div>