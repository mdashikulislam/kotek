<h1 class="pageTitle"><?php echo $title;?></h1>
<script type="text/javascript">
function showModel()
	{
		var groups = new Array;
		var selObj = document.getElementById('make');
		var selIndex = selObj.selectedIndex;
		var searchModel = selObj.options[selIndex].value;
		urlStore ="<? echo base_url();?>index.php/pages/getModelList/"+searchModel;
		
		$.ajax({
				url: urlStore,
				context: document.body,
				success: function(data){
				$("#showModel").html(data);
				}
				});
		
	}

</script>
<script type="text/javascript">
  $(document).ready(function() {

$.validator.addMethod("noSpecialChars", function(value, element) {
      return this.optional(element) || /^[a-z0-9\_\ ]+$/i.test(value);
  }, "This field must contain only letters, numbers, or underscore.");

 $.validator.addMethod("NumbersOnly", function(value, element) {
        return this.optional(element) || /^[0-9\-\ \+]+$/i.test(value);
    }, "Phone must contain only numbers, + and -.");
$.validator.addMethod("selectNone",function(value, element) { 
    if (element.value == "")  {  return false; } else { return true;} },
  "Please select an option.");
 
  $("#createProduct").validate({
        rules: {  
		name:{   required : true},
		part_number:{   required : true},
                shortdesc:{minlength:10,  maxlength: 100},
                longdesc: {minlength:10,  maxlength: 200},
		year_from: { required: true, NumbersOnly:true, minlength:4,  maxlength: 4},
		year_to: { required: true, NumbersOnly:true, minlength:4,  maxlength: 4},
		//price: { required: true,NumbersOnly:true},
		model: { required: true, selectNone:true}

		  },
        messages: { 
		name: { required: "Please enter product name"},
		part_number: { required: "Please enter part number"},
		year_from: { required: "Please enter year from"},
		year_to: { required: "Please enter year to"},
		//price: { required: "Please enter amount"},
		model: { required: "Please choose car model"}
		  
        }       });
      });
  
  </script>
<div class="dashboardWrapper">
<?php
$fdata = array('name'=>'createProduct', 'id'=>'createProduct');
echo form_open_multipart('admin/products/create',$fdata );

echo "<table cellpadding='3' cellspacing='0' border='0' class='createNewTable'>";

echo "<tr>";
echo "<td width='150'><label for='pname'>Name<span class='red'>*</span> :</label></td><td width='810'>";
$data = array('name'=>'name','id'=>'pname','class'=>'textfield','size'=>25, 'value' => '');
echo form_input($data) ."</td>";
echo "</tr>";

echo "<tr>";
echo "<td><label for='short'>Short Description :</label></td><td>";
$data = array('name'=>'shortdesc','id'=>'short','class'=>'textfield','size'=>40, 'value' => '');
echo form_input($data) ."</td>";
echo "</tr>";

echo "<tr>";
echo "<td><label for='long'>Long Description :</label></td><td>";
$data = array('name'=>'longdesc','id'=>'long','rows'=>5, 'cols'=>'40', 'value' =>'');
echo form_textarea($data) ."</td>";
echo "</tr>";

?>
<tr id=''>
<td><label for='long'>Choose Dimensions :</label></td><td>
<div class="dimenWrapper" style="clear:both;">
	<div class="dimenSelect"> Dimentions: </div>
    <div class="dimenValue"> Values: </div>
</div>
<div style="clear:both;"> </div>
<div class="dimenWrapper" id="dimentions_list">
<div class="dimenSelect"><select name="dimentionsList[]" >
<? $dimenList = $this->MDimensions->getAllDimensions();
foreach($dimenList as $key1=>$value1)
{
echo "<option value='".$value1['id']."'>".$value1['name']."</option>";	
}
?>
</select> 
</div>

<div class="dimenValue"><input type="text" class="textfield" id="dimensions[]" value="" name="dimensions[]"></div> 
</div>

<div> <a href="#" onclick="addDie();" class="addDimen" >Add</a></div>

<input type="hidden" name="counter" id="counter" value="1"/></td></tr>
<?
echo "<tr>";
echo "<td>&nbsp;</td>";
//echo "<td>Allowed only gif,jpg or png images with file size of max 200 KB</td>";
echo "</tr>";

echo "<tr>";
echo "<td><label for='uimage'>Image name :</label></td><td>";
$data = array('name'=>'image','id'=>'uimage');
echo form_input($data) ."</td>";
echo "</tr>";
/* 
echo "<tr>";
echo "<td><label for='uthumb'>Upload Thumbnail :</label></td><td>";
$data = array('name'=>'thumbnail','id'=>'uthumb');
echo form_upload($data) ."</td>";
echo "</tr>";
 */
echo "<tr>";
echo "<td><label for='status'>Status :</label></td><td>";
$options = array('active' => 'active', 'inactive' => 'inactive');
echo form_dropdown('status',$options) ."</td>";
echo "</tr>";

echo "<tr>";
echo "<td><label for='group'>Part Number<span class='red'>*</span> :</label></td><td>";
$data = array('name'=>'part_number','id'=>'part_number','class'=>'textfield','size'=>10, 'value' =>'');
echo form_input($data) ."</td>";
echo "</tr>";

echo "<tr>";
echo "<td><label for='group'>Year from<span class='red'>*</span> :</label></td><td>";
$data = array('name'=>'year_from','id'=>'year_from','class'=>'textfield','size'=>10, 'value' =>'');
echo form_input($data) ."</td>";
echo "</tr>";

echo "<tr>";
echo "<td><label for='group'>Year to<span class='red'>*</span> :</label></td><td>";
$data = array('name'=>'year_to','id'=>'year_to','class'=>'textfield','size'=>10, 'value' =>'');
echo form_input($data) ."</td>";
echo "</tr>";

echo "<tr>";
echo "<td><label for='price'>Price<span class='red'>*</span> :</label></td><td>";
$data = array('name'=>'price','id'=>'price','class'=>'textfield','size'=>10, 'value' => '');
echo form_input($data) ."</td>";
echo "</tr>";

echo "<tr>";
echo "<td><label for='price'>Group<span class='red'>*</span> :</label></td><td>";
echo "<select name='group' id='group'>";
foreach ($categories as $key => $value){
	echo "<option value='".$key."' >".$value."</option>";
}
echo "</select>";
echo "</td>";
echo "</tr>";

echo "<tr>";
echo "<td><label for='price'>Maker<span class='red'>*</span> :</label></td><td>";
echo "<select name='make' id='make' onchange='showModel()'> <option value=''>select maker</option>";
foreach ($makers as $key => $value){
	echo "<option value='".$value['id']."' >".$value['name']."</option>";
}
echo "</select>";
echo "</td>";
echo "</tr>";

echo "<tr>";
echo "<td><label for='price'>Model<span class='red'>*</span> :</label></td><td id='showModel'>";
echo "<select name='model' id='model'> <option value=''>select model</option>";
echo "</select>";
echo "</td>";
echo "</tr>";


echo "<tr><td>&nbsp;</td><td>";
echo "<input type='submit' value='' class='createProductBtn' title='Create Product' />";
echo "</td></tr>";

echo "</table>";

echo form_close();


?>
</div>
<script type="text/javascript">
var siteUrl = "<?php echo base_url();?>";
function addDie()
{
	//r couterGet = parseInt($("#counter").val());
	
var	chkUrl = siteUrl+"index.php/admin/dimensions/addDimentions/";

$.ajax({
  url: chkUrl,
  context: document.body,
  success: function(data){	  
    $("#dimentions_list").append(data);
	//couterGet = couterGet + 1;
	//$("#counter").val(couterGet);
  }
});	
	
}

</script>