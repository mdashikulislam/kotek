<h2 class='innerPageTittle'>Testimonials</h2>
<div class='contentWrapper'>
<? foreach($testimonialList as $key=>$value){
?>
<div> <?=$value['description']?><br/> <b><?=$value['title']?></b></div>
<div>&nbsp;</div>
<? } ?>
</div>