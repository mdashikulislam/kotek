<div class="footerTopWrapper">
	<div class="footerBgLeft"> </div>
    <div class="footerBgCenter"> </div>
    <div class="footerBgRight"> </div>
</div>
<p class="copyrights"> Copyright &copy; <?php echo date("Y"); ?> Kotek. All rights reserved. </p>
