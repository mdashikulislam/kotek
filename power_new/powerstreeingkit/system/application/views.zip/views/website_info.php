<div class="main-content">
<div class="top-content-bg"></div>
<div class="content-mid">
<h1>Website Info</h1>
<div style="clear:both"></div>
<p>Coming Soon!!!!!!!!!!!</p>

</div>
<div class="bottom-content-bg"></div>
</div>