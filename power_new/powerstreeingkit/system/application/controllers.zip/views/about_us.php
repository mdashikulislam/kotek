<div class="main-content">
    <div class="about-content">
    	<p><img src="./images/twinkle-story.jpg" alt="" /></p>
        <p><span>O</span>nce upon a time there was a thrilled mother-to-be, <br />who wanted to add a magical touch to her baby's nursery... <br />she searched and searched through the generic world <br />of baby stuff and was not happy with what she found. <br />On a trip back home she came across the touch <br />she had been looking for. Now she wants to share it <br />with other smart mothers-to-be.</p>
        <p>Twinkle My Net canopies enhance every nursery <br />with its own unique personality. They top it off with style! <br />Your baby will sleep under dreamy tulle, safe from critters, <br />hairs and other unwanted guests in a pristine haven.</p>
        <p>Like every good bedtime story, we want <br />every Twinkle My Net to have a happy ending. <br />
        This is why we are committed to donating <br />one mosquito net to a vulnerable <br />baby in need, for every canopy you purchase.</p>
    </div>
</div>