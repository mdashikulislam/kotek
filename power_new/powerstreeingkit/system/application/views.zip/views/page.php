<div id='pleft' class='contentWrapper'>	
<?php echo $page['content'];?>
</div>