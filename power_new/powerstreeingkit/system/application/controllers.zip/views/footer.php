<div class="footerTopWrapper">
	<div class="footerBgLeft"> </div>
    <div class="footerBgCenter"> </div>
    <div class="footerBgRight"> </div>
</div>
<div class="footerBottom">
	<div class="footerClients">
    	<ul class="footerClientList">
        	<li> <img src="./images/clientApra.png" alt="APRA"/> </li>
            <li> <img src="./images/clientCqc.png" alt="CQC"/> </li>
            <li> <img src="./images/clientThird.png" alt=""/> </li>
        </ul>
    </div>
    <div class="footerNavWrapper">
    	<ul class="footerNav">
            <li id="active_one"><a href="<?php echo base_url();?>index.php" title="Home" <? $url_key = $this->uri->segment(2); if($url_key ==''){ echo "class='active'";} else {echo "class='non-active'";}?>>Home</a> | </li>
            <li><a href="<?php echo base_url();?>index.php/pages/filterProduct" title="Products"  rel="facebox" <? $url_key = $this->uri->segment(2); if($url_key =='shop'){ echo "class='active'";}?>>Products</a> | </li>
            <li><a href="<?php echo base_url();?>index.php/pages/promotions" title="Promotions" <? $url_key = $this->uri->segment(2); if($url_key =='giftVoucher'){ echo "class='active'";}?>>Promotions</a> | </li>
            <li><a href="<?php echo base_url()."index.php/pages/view/technical-info";?>" title="Technical Info" <? $url_key = $this->uri->segment(2); if($url_key =='blog-press'){ echo "class='active'";}?>>Technical Info</a> | </li>
            <li><a href="<?php echo base_url();?>index.php/pages/contact" title="Contact Us" <? $url_key = $this->uri->segment(2); if($url_key =='twinkle_gives_back'){ echo "class='active'";}?> style="padding-right:0;">Contact Us</a> | </li>
            <li><a href="<?php echo base_url();?>index.php/pages/order_info" title="Contact Us" <? $url_key = $this->uri->segment(2); if($url_key =='twinkle_gives_back'){ echo "class='active'";}?> style="padding-right:0;">Order Info</a></li>
          </ul>
          <p class="copyrights"> <?php echo date("Y") ?> All Rights Reserved </p>
    </div>
</div>