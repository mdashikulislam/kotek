 <div class="content">
        <?php $this->load->view($main);?>
      </div>