/* ======================================================================================================================================================== */
Facebook like button with faces Code:
/* ======================================================================================================================================================== */
iframe Code::
<iframe src="http://www.facebook.com/plugins/like.php?href=http%3A%2F%2Fwww.twinklemynet.com%2F&amp;layout=standard&amp;show_faces=true&amp;width=200&amp;action=like&amp;font=arial&amp;colorscheme=light&amp;height=80" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:200px; height:80px;" allowTransparency="true"></iframe>
/* ======================================================================================================================================================== */
XFBML Code::
<script src="http://connect.facebook.net/en_US/all.js#xfbml=1"></script><fb:like href="http://www.twinklemynet.com/" show_faces="true" width="200" font="arial"></fb:like>
/* ======================================================================================================================================================== */



/* ======================================================================================================================================================== */
Share this code:
/* ======================================================================================================================================================== */
<script type="text/javascript">var switchTo5x=true;</script><script type="text/javascript" src="http://w.sharethis.com/button/buttons.js"></script><script type="text/javascript">stLight.options({publisher:'4dd31bb1-a49c-4dfb-b9fa-a3cc12c79881'});</script>
/* ======================================================================================================================================================== */
<span class='st_twitter_hcount' displayText='Tweet'></span><span class='st_facebook_hcount' displayText='Facebook'></span>
/* ======================================================================================================================================================== */




/* ================================== */
Share this Account Details:
/* ================================== */
Full Name: Xochitl Saca
Email: xochitl@twinklemynet.com
Username: twinklemynet
Password: tmn@2011
/* ================================== */