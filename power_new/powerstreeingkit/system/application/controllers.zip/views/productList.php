<?
//var_export($productList);
$category = $this->MCats->getCategory($searchGroup);
?>
<div class="breadcrumb"><span class="homeLink"><a href="#" title="Home">Home</a></span> <span class="textBlue">Product</span> <span class="textBlue"> <?=$category['name']?> </span> </div>
<div id="content">
	
     <h1 class="productListTitle">Search Result for <?=$category['name']?></h1>
     <div class="productListWrapper">
     	<table cellpadding="3" cellspacing="0" border="0" class="productListTable">
        <? if(!empty($productList)){ ?>
        	<tr>
				
                <th width="140"> Product </th>
                <th width="140"> Make </th>
                <th width="90"> Year </th>
                <th width="100"> Model </th>
                <th width="360"> Description </th>
                <th width="130"> Part Number </th>
              </tr>
              
            <? $xx =1; foreach($productList as $key=>$value) { 
			if($xx%2 == 0){$cls ="class='even'";}else{$cls ="class='odd'";}
			?>
            <tr <?=$cls?> >
           
            <td align="left"> <?=$value['name']?> </td>
         
            <td align="left"> <?=$value['maker_name']?> </td>
            <td align="center"> <?=$value['year_from']."-".$value['year_to']?> </td>
            <td align="center"> <?=$value['model_name']?> </td>
            <td align="left"> <?=$value['shortdesc']?>  </td>
            <td align="center"> <a href="<? echo base_url(); ?>index.php/pages/product/<?=$value['id']?>" title="<?=$value['name']?>" ><?=$value['part_number']?> </a></td>
             </tr>
            <? $xx++; } ?>
         
             
            <? }else{
            ?>
            <tr>
            <td colspan="6"> No product found </td>
            </tr>
            <? }?>
        </table>
        <div>   <?php echo $this->pagination->create_links(); ?> </div>
    </div>
    
</div>
<div style="clear:both;"></div>


<div class="newSearchWrapper">
    	<h2 class="forgotPwTitle"> Didn't find what you were looking for? </h2>
 	    <div style="text-align:center;"> Please tell us what were you looking for?</div>
            <div id="contactUsForm">
                <form name="contactRequest" id="contactRequest" action="<? echo base_url(); ?>index.php/pages/contactRequest" method="post" />
                <table cellpadding="4" cellspacing="4" class="registrationTable">
                	<tr>
                    	<td width="150"> <label> Name: </label> </td>
                        <td width="200"> <input type="text" name="name" id="name" value="" class="textfield" /> </td>
                    </tr>
                    <tr>
                    	<td> <label> Email: </label> </td>
                        <td> <input type="text" name="email" id="email" value="" class="textfield" /> </td>
                    </tr>
                    <tr>
                    	<td> <label> Message: </label> </td>
                        <td> <textarea name="message" id="message" rows="5" cols="25" class="textarea" ></textarea> </td>
                    </tr>
                    <tr>
                    	<td> &nbsp; </td>
                        <td> <input type="submit" name="submit" id="submit" value="" class="submitBtn" /> </td>
                    </tr>
                </table>
                </form>
            </div>
        </div>


<div style="clear:both;">&nbsp;</div>